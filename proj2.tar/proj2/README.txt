Clark Wood
COP 5570 Project 2 - Makefile
7 October 2013

How to compile and run project:

Known bugs:
    Re-builds things involving .o files, even when it shouldn't
    Some of the commands like multiple commands not working

My assumptions:
    1)  Where parsing is necessary, I assume exactly 1 space 
        in between tokens, except with macros, where I
        assume no spaces.
