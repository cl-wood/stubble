#include<stdio.h>
int main() {
    printf("It works!\n");
}
