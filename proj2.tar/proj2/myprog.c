#include<stdio.h>

int main() 
{
    printf("HERE\n");
}
