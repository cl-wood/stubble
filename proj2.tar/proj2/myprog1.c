#include <stdio.h>
#include "myprog.h"
int main()
{ 
    int i;
    step1();
    step2();
    printf("main step.\n");
    exit(0);
    return 100;
}

