#define MAX_INT 1000
struct dummy {
    int i;
    int j;
};

